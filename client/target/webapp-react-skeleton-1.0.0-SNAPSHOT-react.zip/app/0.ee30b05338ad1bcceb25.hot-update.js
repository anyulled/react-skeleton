webpackHotUpdate(0,{

/***/ 277:
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	
	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
	
	var _tables = __webpack_require__(278);
	
	var actions = _interopRequireWildcard(_tables);
	
	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
	
	var startingColumns = [{
		key: 'id',
		title: 'ID',
		width: 150
	}, {
		key: 'name',
		title: 'Name',
		width: 200
	}, {
		key: 'yearOfBirth',
		title: 'Year of Birth',
		width: 150
	}, {
		key: 'country',
		title: 'Country',
		width: 150
	}, {
		key: 'username',
		title: 'Username',
		width: 150
	}];
	
	var initialState = { //Each table we may perform actions upon requires an object of its own
		userTable: {
			columns: startingColumns, //the first element cannot be ordered no matter what
			rowSortKey: "id",
			rowSortDesc: false
		}
	};
	
	var userTable = function userTable(state, action) {
		switch (action.type) {
			case actions.TABLES_USER_SET_COLUMN_ORDER:
				return _extends({}, state, {
					columns: action.columns
				});
			case actions.TABLES_USER_SET_ROW_ORDER:
				return _extends({}, state, {
					rowSortKey: action.rowSortKey,
					rowSortDesc: state.rowSortKey === action.rowSortKey ? !state.rowSortDesc : false
				});
		}
		return state;
	};
	
	var tables = function tables() {
		var state = arguments.length <= 0 || arguments[0] === undefined ? initialState : arguments[0];
		var action = arguments[1];
	
		if (!action) {
			return state;
		}
	
		switch (action.type) {
			case actions.TABLES_USER_SET_COLUMN_ORDER:
			case actions.TABLES_USER_SET_ROW_ORDER:
				return _extends({}, state, {
					userTable: userTable(state.userTable, action)
				});
		}
		return state;
	};
	
	exports.default = tables;

/***/ },

/***/ 278:
/***/ function(module, exports) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.userTableColumnOrderSet = userTableColumnOrderSet;
	exports.userTableRowOrderSet = userTableRowOrderSet;
	var TABLES_USER_SET_COLUMN_ORDER = exports.TABLES_USER_SET_COLUMN_ORDER = "tables/user/column_order/set";
	var TABLES_USER_SET_ROW_ORDER = exports.TABLES_USER_SET_ROW_ORDER = "tables/user/row_sort_key/set";
	
	function userTableColumnOrderSet(columns) {
		return {
			type: TABLES_USER_SET_COLUMN_ORDER,
			columns: columns
		};
	}
	
	function userTableRowOrderSet(rowSortKey) {
		return {
			type: TABLES_USER_SET_ROW_ORDER,
			rowSortKey: rowSortKey
		};
	}

/***/ },

/***/ 603:
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	
	var _react = __webpack_require__(2);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactRedux = __webpack_require__(173);
	
	var _users = __webpack_require__(250);
	
	var userActions = _interopRequireWildcard(_users);
	
	var _tables = __webpack_require__(278);
	
	var tableActions = _interopRequireWildcard(_tables);
	
	var _modal = __webpack_require__(276);
	
	var modalActions = _interopRequireWildcard(_modal);
	
	var _SortableTable = __webpack_require__(721);
	
	var _SortableTable2 = _interopRequireDefault(_SortableTable);
	
	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var mapStateToProps = function mapStateToProps(state, ownProps) {
		return {
			data: state.users,
			columns: state.tables.userTable.columns,
			rowSortKey: state.tables.userTable.rowSortKey,
			rowSortDesc: state.tables.userTable.rowSortDesc
		};
	};
	//import SortHeaderCell from '../components/SortHeaderCell';
	
	
	var mapDispatchToProps = function mapDispatchToProps(dispatch) {
		return {
			dataLoad: function dataLoad() {
				dispatch(userActions.usersLoad());
			},
			onRemoveClick: function onRemoveClick(id) {
				dispatch(userActions.userRemove(id));
			},
			onEditClick: function onEditClick(user) {
				dispatch(modalActions.modalEditUser(user));
			},
			tableColumnOrderSet: function tableColumnOrderSet(columns) {
				dispatch(tableActions.userTableColumnOrderSet(columns));
			},
			sortRowsBy: function sortRowsBy(sortKey) {
				dispatch(tableActions.userTableRowOrderSet(sortKey));
			}
		};
	};
	
	exports.default = (0, _reactRedux.connect)(mapStateToProps, mapDispatchToProps)(_SortableTable2.default);

/***/ },

/***/ 721:
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	
	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _react = __webpack_require__(2);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _fixedDataTable = __webpack_require__(604);
	
	var _reactBootstrap = __webpack_require__(342);
	
	var _TextCell = __webpack_require__(653);
	
	var _TextCell2 = _interopRequireDefault(_TextCell);
	
	var _SortHeaderCell = __webpack_require__(722);
	
	var _SortHeaderCell2 = _interopRequireDefault(_SortHeaderCell);
	
	__webpack_require__(654);
	
	__webpack_require__(656);
	
	__webpack_require__(658);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
	
	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
	
	var SortableTable = function (_React$Component) {
		_inherits(SortableTable, _React$Component);
	
		function SortableTable(props) {
			_classCallCheck(this, SortableTable);
	
			var _this = _possibleConstructorReturn(this, (SortableTable.__proto__ || Object.getPrototypeOf(SortableTable)).call(this, props));
	
			_this.onColumnReorderEndCallback = _this.onColumnReorderEndCallback.bind(_this);
			return _this;
		}
	
		_createClass(SortableTable, [{
			key: "componentWillMount",
			value: function componentWillMount() {
				if (typeof this.props.dataLoad === "function") {
					this.props.dataLoad();
				}
			}
		}, {
			key: "onColumnReorderEndCallback",
			value: function onColumnReorderEndCallback(event) {
				console.log(event);
				var reorderColumn = this.props.columns.filter(function (column) {
					return column.key === event.reorderColumn;
				})[0];
				var columns = this.props.columns.filter(function (column) {
					return column.key !== event.reorderColumn;
				});
				if (event.columnAfter) {
					//var index = columns.indexOf(event.columnAfter);
					var index = columns.map(function (column, index) {
						if (column.key === event.columnAfter) {
							return column.key;
						}
					}).indexOf(event.columnAfter);
					columns.splice(index, 0, reorderColumn);
				} else {
					columns.push(reorderColumn);
				}
				this.props.tableColumnOrderSet(columns);
			}
		}, {
			key: "sortData",
			value: function sortData(data) {
				var dat = [].concat(_toConsumableArray(data));
				var _props = this.props;
				var rowSortKey = _props.rowSortKey;
				var rowSortDesc = _props.rowSortDesc;
	
				var multiplier = rowSortDesc ? -1 : 1;
				return dat.sort(function (a, b) {
					var aVal = a[rowSortKey] || 0;
					var bVal = b[rowSortKey] || 0;
					return aVal > bVal ? multiplier : aVal < bVal ? -multiplier : 0;
				});
			}
		}, {
			key: "render",
			value: function render() {
				var _props2 = this.props;
				var data = _props2.data;
				var onEditClick = _props2.onEditClick;
				var onRemoveClick = _props2.onRemoveClick;
				var edit = _props2.edit;
				var rowSortKey = _props2.rowSortKey;
				var rowSortDesc = _props2.rowSortDesc;
				var sortRowsBy = _props2.sortRowsBy;
				var columns = _props2.columns;
				var reorderableColumns = _props2.reorderableColumns;
				var reorderableRows = _props2.reorderableRows;
				var rowHeight = _props2.rowHeight;
	
				var sortedData = this.sortData(data);
				var sortProps = { sortBy: sortRowsBy, sortKey: rowSortKey, sortDesc: rowSortDesc };
				var width = Object.keys(columns).reduce(function (prevCol, key) {
					return prevCol + columns[key].width;
				}, 0);
				return _react2.default.createElement(
					_fixedDataTable.Table,
					_extends({
						height: data.length * rowHeight,
						rowsCount: data.length,
						onColumnReorderEndCallback: this.onColumnReorderEndCallback,
						isColumnReordering: false,
						width: width + (edit ? 100 : 0),
						rowHeight: rowHeight,
						headerHeight: rowHeight
					}, this.props),
					columns.map(function (column, i) {
						return _react2.default.createElement(_fixedDataTable.Column, {
							allowCellsRecycling: true,
							columnKey: column.key,
							key: i,
							isReorderable: reorderableColumns,
							header: reorderableRows ? _react2.default.createElement(
								_SortHeaderCell2.default,
								sortProps,
								column.title
							) : _react2.default.createElement(
								_fixedDataTable.Cell,
								null,
								column.title
							),
							cell: _react2.default.createElement(_TextCell2.default, { data: sortedData, col: column.key }),
							width: column.width
						});
					}),
					edit ? _react2.default.createElement(_fixedDataTable.Column, { isReorderable: false, width: 100, header: "Actions",
						cell: function cell(_ref) {
							var rowIndex = _ref.rowIndex;
	
							var props = _objectWithoutProperties(_ref, ["rowIndex"]);
	
							return _react2.default.createElement(
								_fixedDataTable.Cell,
								null,
								_react2.default.createElement(
									"div",
									{ style: { cursor: "pointer", display: "inline" }, onClick: function onClick() {
											onEditClick(sortedData[rowIndex]);
										} },
									_react2.default.createElement(_reactBootstrap.Glyphicon, { glyph: "pencil" })
								)
							);
						}
					}) : null
				);
			}
		}]);
	
		return SortableTable;
	}(_react2.default.Component);
	
	;
	
	SortableTable.defaultProps = {
		edit: false,
		reorderableColumns: true,
		reorderableRows: true,
		rowHeight: 30
	};
	
	SortableTable.propTypes = {
		data: _react.PropTypes.arrayOf(_react.PropTypes.object.isRequired).isRequired,
		dataLoad: _react.PropTypes.func,
		onRemoveClick: _react.PropTypes.func.isRequired,
		onEditClick: _react.PropTypes.func.isRequired,
		tableColumnOrderSet: _react.PropTypes.func.isRequired,
		edit: _react.PropTypes.bool.isRequired,
		rowSortKey: _react.PropTypes.string.isRequired,
		rowSortDesc: _react.PropTypes.bool.isRequired,
		sortRowsBy: _react.PropTypes.func.isRequired,
		columns: _react.PropTypes.arrayOf(_react.PropTypes.shape({
			key: _react.PropTypes.oneOfType([_react.PropTypes.string, _react.PropTypes.number]).isRequired,
			title: _react.PropTypes.oneOfType([_react.PropTypes.string, _react.PropTypes.number]).isRequired,
			width: _react.PropTypes.number.isRequired
		}).isRequired).isRequired,
		reorderableColumns: _react.PropTypes.bool.isRequired,
		rowHeight: _react.PropTypes.number.isRequired
	};
	
	exports.default = SortableTable;

/***/ },

/***/ 722:
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	
	var _react = __webpack_require__(2);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _fixedDataTable = __webpack_require__(604);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }
	
	function renderSortArrow(sortKey, sortDesc, sortId) {
		return sortKey === sortId ? sortDesc ? '↓' : '↑' : '';
	}
	
	var SortHeaderCell = function SortHeaderCell(_ref) {
		var children = _ref.children;
		var sortBy = _ref.sortBy;
		var sortKey = _ref.sortKey;
		var sortDesc = _ref.sortDesc;
		var columnKey = _ref.columnKey;
	
		var props = _objectWithoutProperties(_ref, ["children", "sortBy", "sortKey", "sortDesc", "columnKey"]);
	
		var clickFunc = function clickFunc() {
			return sortBy(columnKey);
		};
		return _react2.default.createElement(
			_fixedDataTable.Cell,
			props,
			_react2.default.createElement(
				"a",
				{ onClick: clickFunc },
				children,
				" ",
				renderSortArrow(sortKey, sortDesc, columnKey)
			)
		);
	};
	
	SortHeaderCell.propTypes = {
		sortBy: _react2.default.PropTypes.func.isRequired,
		sortKey: _react2.default.PropTypes.string.isRequired,
		sortDesc: _react2.default.PropTypes.bool.isRequired,
		columnKey: _react2.default.PropTypes.string,
		children: _react2.default.PropTypes.any
	};
	
	exports.default = SortHeaderCell;

/***/ }

})
//# sourceMappingURL=0.ee30b05338ad1bcceb25.hot-update.js.map